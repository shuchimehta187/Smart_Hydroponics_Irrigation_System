# Instructions

The files in this folder are only for the purpose of seeding data. They are used to populate the database with initial data for testing and development purposes.